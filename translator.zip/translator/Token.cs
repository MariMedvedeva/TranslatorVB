﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Translator
{
    public class Token
    {
        public TokenType Type;
        public string Value;
        public enum TokenType
        {
            INTEGER, SINGLE, DOUBLE, LITERAL, NUMBER, IDENTIFIER,
            IF, THEN, ELSE, DIM, AS, TRUE, FALSE, LBRACKET, RBRACKET, END,
            PLUS, MINUS, EQUAL, MULTIPLICATION, DIVISION, ENTER,
            SEMICOLON, LESS, MORE, COMMA, OR, AND, NOEQUALS
        }
        public Token(TokenType type)
        {
            Type = type;
        }
        public override string ToString()
        {
            if (Value != null)
            {
                return string.Format("{0}, {1}", Type, Value);
            }
            else
            {
                return string.Format($"{Type}");
            }
        }
        public static TokenType[] Delimiters = new TokenType[]
        {
             TokenType.PLUS, TokenType.MINUS, TokenType.ENTER,
             TokenType.EQUAL, TokenType.LBRACKET, TokenType.RBRACKET
        };
        public static bool IsDelimiter(Token token)
        {
            return Delimiters.Contains(token.Type);
        }
        public static Dictionary<string, TokenType> SpecialWords = new
       Dictionary<string, TokenType>()
             {
             { "integer", TokenType.INTEGER },
             { "single", TokenType.SINGLE },
             { "double", TokenType.DOUBLE },
             { "Dim", TokenType.DIM },
             { "as", TokenType.AS },
             { "if", TokenType.IF },
             { "then", TokenType.THEN },
             { "end", TokenType.END },
             { "<>", TokenType.NOEQUALS },
             { "or", TokenType.OR },
             { "and", TokenType.AND },
             { ">", TokenType.MORE},
             { "<", TokenType.LESS},
             { "=", TokenType.EQUAL},
             { "+", TokenType.PLUS},
             { "-", TokenType.MINUS},
             { "*", TokenType.MULTIPLICATION},
             { ":", TokenType.DIVISION},
             { ")", TokenType.RBRACKET},
             { "(", TokenType.LBRACKET},
             { ",", TokenType.COMMA},
             { "else", TokenType.ELSE }
             };
        public static bool IsSpecialWord(string word)
        {
            if (string.IsNullOrEmpty(word))
            {
                return false;
            }
            return (SpecialWords.ContainsKey(word));
        }
    }
}
