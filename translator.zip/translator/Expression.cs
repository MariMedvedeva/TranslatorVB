﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Translator
{
    public class Expression
    {
        List<Token> logicExprStack = new List<Token>();
        Stack<string> stackOfOperations = new Stack<string>();
        Stack<int> priorityStack = new Stack<int>();
        int index = 0;
        string output = null;
        Dictionary<string, int> priority = new Dictionary<string, int>() //Список приоритетов для операций
        {
            {"(", 0},
            {")", 1},
            {"or", 2},
            {"and", 3},
            {"<=", 4}, {">=", 4}, {"<", 4}, {">", 4}, {"=",4}, {"<>", 4},
            {"+", 5}, {"-", 5},
            {"*", 6}, {"/", 6}
        };
        public void TakeToken(Token token)//Получение из анализатора логического выражения
        {
            logicExprStack.Add(token);
        }
        public void Start()//начало программы
        {
            Dijkstra();
            ReversePolishNotation();
        }
        private void PushesOutOperationsHighestPriority(string operation)//Вспомогательная функция для метода Дейкстры  
        {
            int count = stackOfOperations.Count();
            Stack<string> temp = new Stack<string>();//Вспомогательный стек для выполнения выталкивания операций с большим приоритетом 
            Stack<int> priorityTemp = new Stack<int>();//Вспомогательный стек приоритетов для выполнения выталкивания операций с большим приоритетом
            for (int i = 0; i < count; i++)//Цикл выталкивания
            {
                if (priorityStack.Peek() >= priority[operation])
                {
                    output += stackOfOperations.Pop();
                    priorityStack.Pop();
                }
                else
                {
                    temp.Push(stackOfOperations.Pop());
                    priorityTemp.Push(priorityStack.Pop());
                }
            }
            temp.Reverse();
            priorityTemp.Reverse();
            int countTemp = temp.Count();//Цикл возврата операций, которые не были вытолкнуты
            for (int i = 0; i < countTemp; i++)
            {
                stackOfOperations.Push(temp.Pop());
                priorityStack.Push(priorityTemp.Pop());
            }
            stackOfOperations.Push(logicExprStack[index].Value);
            priorityStack.Push(priority[operation]);
        }

        private void Dijkstra()//Метод Дейкстры
        {
            if (logicExprStack[index].Type == Token.TokenType.IDENTIFIER || logicExprStack[index].Type == Token.TokenType.NUMBER || 
                logicExprStack[index].Type == Token.TokenType.LBRACKET)
            {
                priorityStack.Push(0);
                
                while (index != logicExprStack.Count())//Цикл выполняющий метод дейкстры
                {
                    if (logicExprStack[index].Type == Token.TokenType.NUMBER || logicExprStack[index].Type == Token.TokenType.IDENTIFIER)
                    {
                        output += " " +logicExprStack[index].Value + " ";
                        index++;
                    }

                    else if (logicExprStack[index].Type == Token.TokenType.LESS && logicExprStack[index + 1].Type == Token.TokenType.EQUAL)
                    {
                        string operation = "<=";
                        if ((priority[operation] > priorityStack.Peek()) || stackOfOperations.Count() == 0)
                        {
                            stackOfOperations.Push(logicExprStack[index].Value + logicExprStack[index + 1].Value + " ");
                            priorityStack.Push(priority[operation]);
                        }
                        else
                        {
                            PushesOutOperationsHighestPriority(operation);
                        }
                        index++;
                        index++;
                    }

                    else if (logicExprStack[index].Type == Token.TokenType.MORE && logicExprStack[index + 1].Type == Token.TokenType.EQUAL)
                    {
                        string operation = ">=";
                        if ((priority[operation] > priorityStack.Peek()) || stackOfOperations.Count() == 0)
                        {
                            stackOfOperations.Push(logicExprStack[index].Value + logicExprStack[index + 1].Value + " ");
                            priorityStack.Push(priority[operation]);
                        }
                        else
                        {
                            PushesOutOperationsHighestPriority(operation);
                        }
                        index++;
                        index++;
                    }

                    else if (logicExprStack[index].Type == Token.TokenType.LESS && logicExprStack[index + 1].Type == Token.TokenType.MORE)
                    {
                        string operation = "<>";
                        if ((priority[operation] > priorityStack.Peek()) || stackOfOperations.Count() == 0)
                        {
                            stackOfOperations.Push(logicExprStack[index].Value + logicExprStack[index + 1].Value + " ");
                            priorityStack.Push(priority[operation]);
                        }
                        else
                        {
                            PushesOutOperationsHighestPriority(operation);
                        }
                        index++;
                        index++;
                    }

                    else if (logicExprStack[index].Type == Token.TokenType.LESS)
                    {
                        string operation = "<";
                        if ((priority[operation] > priorityStack.Peek()) || stackOfOperations.Count() == 0)
                        {
                            stackOfOperations.Push(logicExprStack[index].Value + " ");
                            priorityStack.Push(priority[operation]);
                        }
                        else
                        {
                            PushesOutOperationsHighestPriority(operation);
                        }
                        index++;
                    }

                    else if (logicExprStack[index].Type == Token.TokenType.MORE)
                    {
                        string operation = ">";
                        if ((priority[operation] > priorityStack.Peek()) || stackOfOperations.Count() == 0)
                        {
                            stackOfOperations.Push(logicExprStack[index].Value + " ");
                            priorityStack.Push(priority[operation]);
                        }
                        else
                        {
                            PushesOutOperationsHighestPriority(operation);
                        }
                        index++;
                    }

                    else if (logicExprStack[index].Type == Token.TokenType.EQUAL)
                    {
                        string operation = "=";
                        if ((priority[operation] > priorityStack.Peek()) || stackOfOperations.Count() == 0)
                        {
                            stackOfOperations.Push(logicExprStack[index].Value + " ");
                            priorityStack.Push(priority[operation]);
                        }
                        else
                        {
                            PushesOutOperationsHighestPriority(operation);
                        }
                        index++;
                    }

                    else if (logicExprStack[index].Type == Token.TokenType.OR)
                    {
                        string operation = "or";
                        if ((priority[operation] > priorityStack.Peek()) || stackOfOperations.Count() == 0)
                        {
                            stackOfOperations.Push(" " + logicExprStack[index].Value + " ");
                            priorityStack.Push(priority[operation]);
                        }
                        else
                        {
                            PushesOutOperationsHighestPriority(operation);
                        }
                        index++;
                    }

                    else if (logicExprStack[index].Type == Token.TokenType.AND)
                    {
                        string operation = "and";
                        if ((priority[operation] > priorityStack.Peek()) || stackOfOperations.Count() == 0)
                        {
                            stackOfOperations.Push(" " + logicExprStack[index].Value + " ");
                            priorityStack.Push(priority[operation]);
                        }
                        else
                        {
                            PushesOutOperationsHighestPriority(operation);
                        }
                        index++;
                    }

                    else if (logicExprStack[index].Type == Token.TokenType.PLUS)
                    {
                        string operation = "+";

                        if ((priority[operation] > priorityStack.Peek()) || stackOfOperations.Count() == 0)
                        {
                            stackOfOperations.Push(logicExprStack[index].Value + " ");
                            priorityStack.Push(priority[operation]);
                        }
                        else
                        {
                            PushesOutOperationsHighestPriority(operation);
                        }
                        index++;
                    }

                    else if (logicExprStack[index].Type == Token.TokenType.MINUS)
                    {
                        string operation = "-";

                        if ((priority[operation] > priorityStack.Peek()) || stackOfOperations.Count() == 0)
                        {
                            stackOfOperations.Push(logicExprStack[index].Value + " ");
                            priorityStack.Push(priority[operation]);
                        }
                        else
                        {
                            PushesOutOperationsHighestPriority(operation);
                        }
                        index++;
                    }

                    else if (logicExprStack[index].Type == Token.TokenType.MULTIPLICATION)
                    {
                        string operation = "*";

                        if ((priority[operation] > priorityStack.Peek()) || stackOfOperations.Count() == 0)
                        {
                            stackOfOperations.Push(logicExprStack[index].Value + " ");
                            priorityStack.Push(priority[operation]);
                        }
                        else
                        {
                            PushesOutOperationsHighestPriority(operation);
                        }
                        index++;
                    }

                    else if (logicExprStack[index].Type == Token.TokenType.DIVISION)
                    {
                        string operation = "/";

                        if ((priority[operation] > priorityStack.Peek()) || stackOfOperations.Count() == 0)
                        {
                            stackOfOperations.Push(logicExprStack[index].Value + " ");
                            priorityStack.Push(priority[operation]);
                        }
                        else
                        {
                            PushesOutOperationsHighestPriority(operation);
                        }
                        index++;
                    }

                    else if (logicExprStack[index].Type == Token.TokenType.LBRACKET)
                    {
                        string operation = "(";

                        if ((priority[operation] > priorityStack.Peek()) || stackOfOperations.Count() == 0)
                        {
                            stackOfOperations.Push(logicExprStack[index].Value);
                            priorityStack.Push(priority[operation]);
                        }
                        else
                        {
                            stackOfOperations.Push(operation);
                            priorityStack.Push(priority[operation]);
                        }
                        index++;
                    }

                    else if (logicExprStack[index].Type == Token.TokenType.RBRACKET)
                    {
                        string operation = ")";

                        if ((priority[operation] > priorityStack.Peek()) || stackOfOperations.Count() == 0)
                        {
                            stackOfOperations.Push(logicExprStack[index].Value);
                            priorityStack.Push(priority[operation]);
                        }
                        else
                        {
                            PushesOutOperationsHighestPriority(operation);
                            stackOfOperations.Pop();
                            stackOfOperations.Pop();
                            priorityStack.Pop();
                            priorityStack.Pop();
                        }
                        index++;
                    }

                    else if (logicExprStack[index].Type == Token.TokenType.THEN)
                    {
                        break;
                    }
                    else
                    {
                        throw new Exception("Неверно составлено логическое выражение.");
                    }
                }
                int countOperations = stackOfOperations.Count();
                for (int i = 0; i < countOperations; i++)//выталкивание всех оставшихся операций в стеке
                {
                    output += stackOfOperations.Pop();
                }

            }
            else
                throw new Exception("Неверно составлено логическое выражение: ожидался identifier или (.");
        }
        public void ReversePolishNotation()//преобразование обратной польской нотации в матричный вид
        {
            Dictionary<int, string> M = new Dictionary<int, string>();
            Stack<string> stackOperand = new Stack<string>();
            int key = 1;
            for (int i = 0; i < output.Count(); i++)
            {
                char currentChar = output[i];
                switch (currentChar)
                {
                    case ('<'):
                        {
                            if (i < output.Count() - 1)
                            {
                                if (output[i + 1] == '=')
                                {
                                    M.Add(key, "<= " + stackOperand.Pop() + " " + stackOperand.Pop());
                                    stackOperand.Push(M + key.ToString());
                                    key++;
                                    i++;
                                }
                                else if (output[i + 1] == '>')
                                {
                                    M.Add(key, "<> " + stackOperand.Pop() + " " + stackOperand.Pop());
                                    stackOperand.Push("M" + key.ToString());
                                    key++;
                                    i++;
                                }
                                else
                                {
                                    M.Add(key, "< " + stackOperand.Pop() + " " + stackOperand.Pop());
                                    stackOperand.Push("M" + key.ToString());
                                    key++;
                                }
                            }
                            else
                            {
                                M.Add(key, "< " + stackOperand.Pop() + " " + stackOperand.Pop());
                                stackOperand.Push("M" + key.ToString());
                                key++;
                            }
                            
                            break;
                        }
                    case ('>'):
                        {
                            if (i < output.Count() - 1)
                            {
                                if (output[i + 1] == '=')
                                {
                                    M.Add(key, ">= " + stackOperand.Pop() + " " + stackOperand.Pop());
                                    stackOperand.Push("M" + key.ToString());
                                    key++;
                                    i++;
                                }
                                else
                                {
                                    M.Add(key, "> " + stackOperand.Pop() + " " + stackOperand.Pop());
                                    stackOperand.Push("M" + key.ToString());
                                    key++;
                                }
                            }
                            else
                            {
                                M.Add(key, "> " + stackOperand.Pop() + " " + stackOperand.Pop());
                                stackOperand.Push("M" + key.ToString());
                                key++;
                            }
                            
                            break;
                        }

                    case ('='):
                        {
                            M.Add(key, "= " + stackOperand.Pop() + " " + stackOperand.Pop());
                            stackOperand.Push("M" + key.ToString());
                            key++;
                            break;
                        }

                    case ('o'):
                        {
                            if (i <= output.Count() - 2)
                            {
                                if (output[i + 1] == 'r')
                                {
                                    M.Add(key, "or " + stackOperand.Pop() + " " + stackOperand.Pop());
                                    stackOperand.Push("M" + key.ToString());
                                    key++;
                                    i++;
                                }
                                else
                                {
                                    stackOperand.Push(currentChar.ToString());
                                }
                                break;
                            }
                            else
                            {
                                stackOperand.Push(currentChar.ToString());
                            }
                            break;
                        }

                    case ('a'):
                        {
                            if(i <= output.Count() - 2)
                            {
                                if (output[i + 1] == 'n' && output[i + 2] == 'd')
                                {
                                    M.Add(key, "and " + stackOperand.Pop() + " " + stackOperand.Pop());
                                    stackOperand.Push("M" + key.ToString());
                                    key++;
                                    i++;
                                    i++;
                                }
                                else
                                {
                                    stackOperand.Push(currentChar.ToString());
                                }
                                break;
                            }
                            else
                            {
                                stackOperand.Push(currentChar.ToString());
                            }
                            break;
                        }

                    case ('+'):
                        {
                            M.Add(key, "+" + " " + stackOperand.Pop() + " " + stackOperand.Pop());
                            stackOperand.Push("M" + key.ToString());
                            key++;
                            break;
                        }

                    case ('-'):
                        {
                            M.Add(key, "-" + " " + stackOperand.Pop() + " " + stackOperand.Pop());
                            stackOperand.Push("M" + key.ToString());
                            key++;
                            break;
                        }

                    case ('*'):
                        {
                            M.Add(key, "*" + " " + stackOperand.Pop() + " " + stackOperand.Pop());
                            stackOperand.Push("M" + key.ToString());
                            key++;
                            break;
                        }

                    case ('/'):
                        {
                            M.Add(key, "/" + " " + stackOperand.Pop() + " " + stackOperand.Pop());
                            stackOperand.Push("M" + key.ToString());
                            key++;
                            break;
                        }

                    default:
                        {
                            if (Regex.IsMatch(currentChar.ToString(), "^[a-zA-Z]+$") || Regex.IsMatch(currentChar.ToString(), "^[0-9]+$"))
                            {
                                string temp = null;
                                while (output[i] != ' ')
                                {
                                    temp += output[i].ToString();
                                    i++;
                                }
                                stackOperand.Push(temp);
                            }
                            else if (currentChar == ' ')
                            {
                            }
                            else
                            {
                                throw new System.Exception("Ошибка логического выражения: неверно составлено логическое выражение.");
                            }
                            break;
                        }
                }
            }
            Form1._Form1.update("Обратная польская нотация:");
            Form1._Form1.update(output);
            Form1._Form1.update("Матричный вид:");
            int countOutput = stackOperand.Count;
            for (int i = 1; i < countOutput; i++)
            {
                Form1._Form1.update(stackOperand.Pop());
            }
            int countM = M.Count;
            for (int i = 1; i < countM + 1; i++)
            {
                Form1._Form1.update("M" + i + ": " + M[i]);
            }
            Form1._Form1.update(" ");
        }
    }
}
