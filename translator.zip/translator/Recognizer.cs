﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Translator
{
    public class Recognizer
    {
        Token token;
        List<Token> tok1 = new List<Token>();
        public bool Succes;
        int i;
        public Recognizer(List<Token> listtok)
        {
            tok1 = listtok;
        }

        public void Begin()
        {
            i = -1;
            try
            {
                Programm();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка синтаксического анализа", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void Programm()// программа
        {
            Succes = false;
            Next();
            ListOfOperations();
            Succes = true;
        }
        public void ListOfOperations()// спис_опер
        {
            Operator();
            if (token.Type != Token.TokenType.ENTER)
            {
                Error("enter", token.Type);
            }
            Next();
            AddOper();
        }
        public void AddOper()// доп_опер
        {
            while (i < tok1.Count)
            {
                Operator();
                if (token.Type != Token.TokenType.ENTER)
                {
                    Error("enter", token.Type);
                }
                Next();
            }
        }
        public void Type()// тип
        {
            if (token.Type != Token.TokenType.INTEGER && token.Type != Token.TokenType.SINGLE && token.Type != Token.TokenType.DOUBLE)
            {
                Error("integer, single или double", token.Type);
            }
            Next();
        }
        public void ListOfVariables()// спис_перем
        {
            if (token.Type != Token.TokenType.IDENTIFIER)
            {
                Error("identifier", token.Type);
            }
            Next();
            AddVar();
        }
        public void AddVar()// доп. перем
        {
            if (token.Type == Token.TokenType.COMMA)
            {
                Next();
                if (token.Type != Token.TokenType.IDENTIFIER)
                {
                    Error("identifier", token.Type);
                }
                Next();
                AddVar();
            }
        }
        public void Operator()// опер
        {
            switch (token.Type)
            {
                case Token.TokenType.DIM:
                    Declaration();
                    break;
                case Token.TokenType.IF:
                    Conditional();
                    break;
                case Token.TokenType.IDENTIFIER:
                    Assignment();
                    break;
                default:
                    Error("DIM, if или identifier", token.Type);
                    break;
            }
        }
        public void Conditional()// условн
        {
            if (token.Type != Token.TokenType.IF)
            {
                Error("if", token.Type);
            }
            Next();
            Expression();
            if (token.Type != Token.TokenType.THEN)
            {
                Error("then", token.Type);
            }
            Next();
            if (token.Type != Token.TokenType.ENTER)
            {
                Error("enter", token.Type);
            }
            Next();
            while(token.Type != Token.TokenType.END && token.Type != Token.TokenType.ELSE)
            {
                Operator();
                if (token.Type != Token.TokenType.ENTER)
                {
                    Error("enter", token.Type);
                }
                Next();
            }
            AddConditional();
        }
        public void AddConditional() //доп. условн
        {
            if (token.Type == Token.TokenType.END)
            {
                Next();
                if (token.Type == Token.TokenType.IF)
                {
                    Next();
                }
            }
            else if (token.Type == Token.TokenType.ELSE)
            {
                Next();
                if (token.Type != Token.TokenType.ENTER)
                {
                    Error("ENTER", token.Type);
                }
                Next();
                while (token.Type != Token.TokenType.END && token.Type != Token.TokenType.ELSE)
                {
                    Operator();
                    if (token.Type != Token.TokenType.ENTER)
                    {
                        Error("enter", token.Type);
                    }
                    Next();
                }
                if (token.Type == Token.TokenType.END)
                {
                    Next();
                    if (token.Type == Token.TokenType.IF)
                    {
                        Next();
                    }
                    else
                        Error("if", token.Type);
                }
            }
            else
            {
                Error("end if или else", token.Type);
            }
        }
        public void Assignment()// присв
        {
            if (token.Type != Token.TokenType.IDENTIFIER)
            {
                Error("identifier", token.Type);
            }
            Next();
            if (token.Type != Token.TokenType.EQUAL)
            {
                Error("=", token.Type);
            }
            Next();
            Operand();
            if (token.Type == Token.TokenType.PLUS || token.Type == Token.TokenType.MINUS 
                || token.Type == Token.TokenType.MULTIPLICATION || token.Type == Token.TokenType.DIVISION)
            {
                Next();
                Operand();
            }
        }
        public void Operand() // операнд 
        {
            if (token.Type == Token.TokenType.IDENTIFIER || token.Type == Token.TokenType.NUMBER)
            {
                Next();
            }
            else
            {
                Error("number или identifier", token.Type);
            }
        }
        private void Declaration() // опис
        {
            if (token.Type != Token.TokenType.DIM)
            {
                Error("DIM", token.Type);
            }
            Next();

            ListOfVariables();

            if (token.Type != Token.TokenType.AS)
            {
                Error("as", token.Type);
            }
            Next();

            Type();
        }
        public void Expression() // выражение
        {
            Expression expr = new Expression();
            while (token.Type != Token.TokenType.THEN || token.Type == Token.TokenType.ENTER)
            {
                if (token.Type == Token.TokenType.ENTER)
                {
                    Error("then", token.Type);
                }
                expr.TakeToken(token);
                Next();
            }
            expr.Start();
        }
        public string Error(string s, Token.TokenType type1)
        {
            throw new Exception($"Ожидался {s}, а встретился {type1}");
        }
        public void Next()
        {
            i++;
            if (i < tok1.Count)
            {
                token = tok1[i];
            }
        }
    }
}
