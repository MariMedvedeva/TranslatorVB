﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Translator
{
    class Lex
    {
        List<char> limiters = new List<char> { ',', '.', ';', '(', ')', '[', ']', '+', '-', '*', '/', '<', '>', ':', '=', '\n' };
        public static bool IsID(char c)
        {
            string chars = "" + c;
            return Regex.IsMatch(chars, "^[a-zA-Z]+$");
        }
        public static bool IsLiteral(char c)
        {
            string chars = "" + c;
            return Regex.IsMatch(chars, "^[0-9]+$");
        }
        public bool IsSeparator(char c)
        {
            char separator = c;
            return limiters.Contains(separator);
        }

    }
}
