﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Translator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            _Form1 = this;
        }

        private void butnOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";
            if (dialog.ShowDialog() == DialogResult.Cancel)
                return;
            string fileName = dialog.FileName;
            string fileText = System.IO.File.ReadAllText(fileName);
            textBox.Text = fileText;
            MessageBox.Show("Файл открыт.", "Файл", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void butnSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog dialog = new SaveFileDialog();
            dialog.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";
            if (dialog.ShowDialog() == DialogResult.Cancel)
                return;
            string fileName = dialog.FileName;
            System.IO.File.WriteAllText(fileName, textBox.Text);
            MessageBox.Show("Файл сохранен.", "Файл", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        List<string> list;
        private void butnAnalyse_Click(object sender, EventArgs e)
        {
            Analyse();
            ClassificationLex();
        }
        int flag = 0;
        private void Analyse()
        {
            listBox1.Items.Clear();
            Lex lex = new Lex();
            char n = '#';
            char[] str = textBox.Text.ToCharArray();
            list = new List<string>();
            bool t = true;
            for (int i = 0; i < str.Length; i++)
            {
                if (Lex.IsID(str[i]) == t)
                {
                    string id = "";
                    while (Lex.IsID(str[i]) == t)
                    {
                        id += str[i];
                        i++;
                        if (i == str.Length)
                            break;
                    }
                    try
                    {
                        if (id.Length > 8)
                        {
                            throw new Exception("Недопустимое кол-во символов идентификатора(более 8-ми).");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Ошибка лексического анализа", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    list.Add($"{id} I");
                    listBox1.Items.Add($"{id} - индификатор");
                }
                if (i < str.Length)
                {
                    if (lex.IsSeparator(str[i]) == t)
                    {
                        if (str[i] == '\n')
                        {
                            list.Add($"{str[i]} #");
                            listBox1.Items.Add($"{n} - конец строки");
                        }
                        else
                        {
                            list.Add($"{str[i]} R");
                            listBox1.Items.Add($"{str[i]} - разделитель");
                        }
                    }
                }
                if (i < str.Length)
                {
                    if (Lex.IsLiteral(str[i]) == true)
                    {
                        string lit = "";
                        while (Lex.IsLiteral(str[i]) == true)
                        {
                            lit += str[i];
                            i++;
                        }
                        list.Add($"{lit} L");
                        listBox1.Items.Add($"{lit} - литерал");
                    }
                }
            }
        }
        private void ClassificationLex()
        {
            List<Token> tkn = new List<Token>();
            listBox2.Items.Clear();
            textOutput.Clear();
            Token token;
            string str;
            string type;
            for (int i = 0; i < list.Count; i++)
            {
                str = list[i].Split(' ')[0];
                type = list[i].Split(' ')[1];
                if (type == "I")
                {
                    if (Token.IsSpecialWord(str))
                    {
                        token = new Token(Token.SpecialWords[str]);
                        token.Value = str;
                        tkn.Add(token);
                        listBox2.Items.Add($"{token}");
                        continue;
                    }
                    else
                    {
                        token = new Token(Token.TokenType.IDENTIFIER);
                        token.Value = str;
                        tkn.Add(token);
                        listBox2.Items.Add($"{token}");
                        continue;
                    }
                }
                else if (type == "L")
                {
                    token = new Token(Token.TokenType.NUMBER);
                    token.Value = str;
                    tkn.Add(token);
                    listBox2.Items.Add($"{token}");
                    continue;
                }
                else if (type == "R")
                {
                    token = new Token(Token.SpecialWords[str]);
                    token.Value = str;
                    tkn.Add(token);
                    listBox2.Items.Add($"{token}");
                    continue;
                }
                else if (type == "#")
                {
                    token = new Token(Token.TokenType.ENTER);
                    tkn.Add(token);
                    listBox2.Items.Add($"{token}");
                    continue;
                }
            }
            Recognizer recognizer = new Recognizer(tkn);
            recognizer.Begin();
            if (recognizer.Succes == true)
                MessageBox.Show("Анализ успешно завершен.", "Анализ завершен", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = listBox1.SelectedIndex;
            if (index != -1)
            {
                listBox2.SelectedIndex = index;
            }
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = listBox2.SelectedIndex;
            if (index != -1)
            {
                listBox1.SelectedIndex = index;
            }
        }
        public static Form1 _Form1;
        public void update(string message)
        {
            textOutput.Text += message + Environment.NewLine;
        }
    }
}
